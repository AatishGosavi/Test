import React, { useState, useMemo, useEffect } from 'react';
import { Search, X, Settings2 } from 'lucide-react';
import Header from './components/layout/Header';
import DataTable from './components/table/DataTable';
import FilterPanel from './components/FilterPanel';

const App = () => {
  const [summaryData, setSummaryData] = useState([]);
  const [detailData, setDetailData] = useState([]);
  const [loading, setLoading] = useState(true);

  // UI States
  const [expandedPOs, setExpandedPOs] = useState(new Set());
  const [expandedBatches, setExpandedBatches] = useState(new Set());
  const [searchTerm, setSearchTerm] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [grafanaUrl, setGrafanaUrl] = useState(null);

  // Advanced Filter States
  const [statusFilter, setStatusFilter] = useState('All');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [paramFilters, setParamFilters] = useState([{ key: 'p1', value: '' }]);

  useEffect(() => {
    const fetchAllData = async () => {
      try {
        setLoading(true);
        const [sumRes, detRes] = await Promise.all([
          fetch('http://localhost:5000/api/production-summary'),
          fetch('http://localhost:5000/api/production')
        ]);
        const summaries = await sumRes.json();
        const details = await detRes.json();
        setSummaryData(summaries);
        setDetailData(details);
        if (summaries.length > 0) setExpandedPOs(new Set([summaries[0].sap_order]));
      } catch (err) {
        console.error("Fetch Error:", err);
      } finally {
        setLoading(false);
      }
    };
    fetchAllData();
  }, []);

  const groupedData = useMemo(() => {
    const map = {};

    summaryData.forEach(row => {
      const poId = row.sap_order;
      
      // Filter Logic
      const matchesSearch = poId?.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesStatus = statusFilter === 'All' || row.status === statusFilter;
      
      // Date Range Logic
      const rowDate = new Date(row.start_date);
      const isAfterStart = !startDate || rowDate >= new Date(startDate);
      const isBeforeEnd = !endDate || rowDate <= new Date(endDate);

      if (matchesSearch && matchesStatus && isAfterStart && isBeforeEnd) {
        map[poId] = {
          summary: { ...row },
          details: detailData.filter(d => d.po === poId)
        };
      }
    });
    return map;
  }, [summaryData, detailData, searchTerm, statusFilter, startDate, endDate,paramFilters]);

   const handleAddParam = () => setParamFilters([...paramFilters, { key: 'p1', value: '' }]);
   const handleRemoveParam = (index) => setParamFilters(paramFilters.filter((_, i) => i !== index));
   const handleParamChange = (index, field, value) => {
    const newParams = [...paramFilters];
    newParams[index][field] = value;
    setParamFilters(newParams);
  }; 
 const togglePO = (id) => {
    const n = new Set(expandedPOs);
    n.has(id) ? n.delete(id) : n.add(id);
    setExpandedPOs(n);
  };
 const resetFilters = () => {
    setStatusFilter('All'); setStartDate(''); setEndDate('');
    setParamFilters([{ key: 'p1', value: '' }]); setSearchTerm('');
  };
  const openDashboard = (id) => {
    
    setGrafanaUrl(`http://localhost:3008/d/315ff920-dd70-44b3-95f4-37f208fcde8a/spc-dashboard-updated?kiosk`);
  };               

  return (
    <div className="min-h-screen bg-[#f8fafc] p-10">
      <div className="max-w-[1600px] mx-auto">
        <Header />
        
        <div className="flex gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
            <input 
              className="w-full pl-16 pr-6 py-5 bg-white border border-slate-200 rounded-[2rem] outline-none shadow-sm focus:ring-4 ring-indigo-500/5 text-lg font-bold" 
              placeholder="Search SAP Order..." 
              value={searchTerm} 
              onChange={e => setSearchTerm(e.target.value)} 
            />
          </div>
          <button 
            onClick={() => setShowFilters(!showFilters)}
            className={`px-8 rounded-[2rem] flex items-center gap-3 font-black uppercase text-xs tracking-widest transition-all border ${showFilters ? 'bg-slate-800 text-white border-slate-800' : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'}`}
          >
            <Settings2 size={18} />
            Advanced Filters
          </button>
        </div>

        {showFilters && (
              <FilterPanel 
                setShowFilters={setShowFilters} statusFilter={statusFilter} setStatusFilter={setStatusFilter}
                startDate={startDate} setStartDate={setStartDate} endDate={endDate} setEndDate={setEndDate}
                paramFilters={paramFilters} onAddParam={handleAddParam} onRemoveParam={handleRemoveParam}
                onParamChange={handleParamChange} resetFilters={resetFilters}
              />
            )}

        {loading ? (
          <div className="text-center py-20 font-black text-slate-400 animate-pulse uppercase tracking-widest">Initialising Production Stream...</div>
        ) : (
          <DataTable 
            groupedData={groupedData} 
            expandedPOs={expandedPOs} 
            togglePO={togglePO}
            expandedBatches={expandedBatches}
            toggleBatch={(id) => {
              const n = new Set(expandedBatches);
              n.has(id) ? n.delete(id) : n.add(id);
              setExpandedBatches(n);
            }}
            onOpenDashboard={(type, id) => openDashboard(id)} 
          />
        )}
      </div>

      {grafanaUrl && (
        <div className="fixed inset-0 z-[100] bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-12">
          <div className="bg-white w-full h-full rounded-[3rem] shadow-2xl flex flex-col overflow-hidden">
            <div className="px-10 py-6 border-b flex justify-between items-center bg-slate-50">
              <h3 className="font-black text-slate-800 uppercase tracking-widest text-xs">Analytics Stream</h3>
              <button onClick={() => setGrafanaUrl(null)} className="p-3 hover:bg-rose-50 hover:text-rose-500 rounded-2xl"><X size={24} /></button>
            </div>
            <iframe src={grafanaUrl} className="flex-1 w-full border-none" />
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
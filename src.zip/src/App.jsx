import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Settings2, 
  ChevronDown, 
  ChevronRight, 
  Box, 
  Activity, 
  Calendar, 
  Layers, 
  X, 
  Plus, 
  Trash2, 
  RefreshCcw, 
  CheckCircle2, 
  XCircle, 
  AlertCircle 
} from 'lucide-react';

/**
 * MOCK DATA
 */
const MOCK_QUERY_DATA = [
  { po: 'PO-2024-001', batch: 'batch1', p1: 'Pass', p10: 'Pass', p11: 'Fail', result: 'Partial', timestamp: '2024-05-20 10:30', abc: 'Val1', def: 'X' },
  { po: 'PO-2024-001', batch: 'batch2', p1: 'Pass', p10: 'Pass', p11: 'Pass', result: 'Pass', timestamp: '2024-05-20 11:15', abc: 'Val2', def: 'Y' },
  { po: 'PO-2024-002', batch: 'batch3', p1: 'Fail', p10: 'N/A', p11: 'N/A', result: 'Fail', timestamp: '2024-05-21 09:00', abc: 'Val1', def: 'Z' },
  { po: 'PO-2024-003', batch: 'batch4', p1: 'Pass', p10: 'Pending', p11: 'N/A', result: 'Running', timestamp: '2024-05-22 12:45', abc: 'Val3', def: 'X' },
];

/**
 * SUB-COMPONENTS
 */

const StatusIcon = ({ status }) => {
  switch (status) {
    case 'Pass': return <CheckCircle2 size={14} className="text-emerald-500" />;
    case 'Fail': return <XCircle size={14} className="text-rose-500" />;
    case 'Running': return <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" />;
    default: return <AlertCircle size={14} className="text-amber-500" />;
  }
};

const Header = () => (
  <div className="flex items-center justify-between mb-8">
    <div className="flex items-center gap-4">
      <div className="p-3 bg-indigo-600 rounded-2xl shadow-xl shadow-indigo-200">
        <Layers className="text-white w-6 h-6" />
      </div>
      <div>
        <h1 className="text-2xl font-black text-slate-800 tracking-tight">Production Intel</h1>
        <p className="text-slate-500 text-[10px] font-bold uppercase tracking-[0.2em]">Operational Matrix v2.4</p>
      </div>
    </div>
    <div className="hidden md:flex gap-2">
      <div className="px-4 py-2 bg-white rounded-xl border border-slate-200 shadow-sm flex items-center gap-2">
        <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
        <span className="text-[10px] font-black text-slate-500 uppercase">System Online</span>
      </div>
    </div>
  </div>
);

const FilterPanel = ({ 
  showFilters, setShowFilters, statusFilter, setStatusFilter, 
  startDate, setStartDate, endDate, setEndDate, 
  paramFilters, handleParamChange, addParamFilter, removeParamFilter, resetFilters 
}) => {
  if (!showFilters) return null;

  return (
    <div className="absolute right-0 mt-4 w-[420px] bg-white border border-slate-200 rounded-[2rem] shadow-[0_20px_50px_rgba(0,0,0,0.15)] p-8 z-50 animate-in fade-in zoom-in-95 slide-in-from-top-4 duration-200">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h4 className="font-black text-slate-800 text-lg tracking-tight">Filter Engine</h4>
          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Refine production view</p>
        </div>
        <button onClick={() => setShowFilters(false)} className="p-2 hover:bg-slate-100 rounded-full transition-colors text-slate-400">
          <X size={20} />
        </button>
      </div>
      
      <div className="space-y-8">
        <div className="space-y-4">
          <div className="flex justify-between items-center px-1">
            <label className="text-[10px] font-black uppercase text-slate-400 tracking-[0.15em]">Specific Parameters</label>
            <button onClick={addParamFilter} className="text-[10px] flex items-center gap-1 font-black text-indigo-600 uppercase tracking-widest">
              <Plus size={14} strokeWidth={3} /> Add Logic
            </button>
          </div>
          <div className="space-y-3 max-h-[180px] overflow-y-auto pr-2">
            {paramFilters.map((filter, idx) => (
              <div key={idx} className="flex gap-2 items-center">
                <div className="flex-1 flex bg-slate-50 rounded-xl border border-slate-200 p-1.5 focus-within:border-indigo-300 transition-all">
                  <select 
                    className="bg-transparent text-[11px] font-black text-indigo-600 uppercase outline-none px-2 border-r border-slate-200"
                    value={filter.key}
                    onChange={(e) => handleParamChange(idx, 'key', e.target.value)}
                  >
                    <option value="abc">ABC</option>
                    <option value="def">DEF</option>
                  </select>
                  <input 
                    type="text"
                    placeholder="Value..."
                    className="flex-1 bg-transparent px-3 py-1.5 text-xs font-bold text-slate-700 outline-none"
                    value={filter.value}
                    onChange={(e) => handleParamChange(idx, 'value', e.target.value)}
                  />
                </div>
                {paramFilters.length > 1 && (
                  <button onClick={() => removeParamFilter(idx)} className="p-2.5 text-slate-300 hover:text-rose-500 transition-all">
                    <Trash2 size={16} />
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="pt-4 flex gap-4">
          <button onClick={resetFilters} className="flex items-center gap-2 px-6 py-3 text-[11px] font-black text-slate-400 uppercase tracking-widest">
            <RefreshCcw size={16} /> Reset
          </button>
          <button onClick={() => setShowFilters(false)} className="flex-1 px-6 py-4 text-[11px] font-black text-white uppercase tracking-[0.2em] bg-indigo-600 rounded-2xl shadow-lg">
            Update View
          </button>
        </div>
      </div>
    </div>
  );
};

const BatchDetailRow = ({ batch }) => (
  <React.Fragment>
    <tr className="bg-white/80">
      <td className="p-0 border-l-[8px] border-indigo-600"></td>
      {['p1', 'p10', 'p11', 'Status'].map(h => (
        <td key={h} className="py-3 border-l border-slate-50 text-center font-black text-[9px] uppercase tracking-widest text-slate-400 bg-slate-50/30">
          {h}
        </td>
      ))}
    </tr>
    <tr className="bg-white group/data">
      <td className="px-8 py-6 pl-24 border-l-[8px] border-indigo-600 relative">
        <div className="absolute left-[5.5rem] top-0 bottom-0 w-0.5 bg-slate-100"></div>
        <div className="flex flex-col">
          <span className="text-[9px] font-black text-slate-300 uppercase tracking-widest mb-1">Time Captured</span>
          <div className="flex items-center gap-2 text-xs font-mono font-bold text-slate-600">
            <Calendar size={12} className="text-indigo-400" />
            {batch.timestamp}
          </div>
        </div>
      </td>
      {[batch.p1, batch.p10, batch.p11].map((val, i) => (
        <td key={i} className="px-8 py-6 border-l border-slate-50 text-center">
          <div className="flex flex-col items-center gap-2">
            <StatusIcon status={val} />
            <span className="text-[10px] font-black text-slate-700 uppercase tracking-tighter">{val}</span>
          </div>
        </td>
      ))}
      <td className="px-8 py-6 border-l border-slate-50 text-center">
        <span className={`inline-flex items-center gap-2 px-4 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-wider border ${
          batch.result === 'Pass' ? 'bg-emerald-50 text-emerald-700 border-emerald-100' : 
          batch.result === 'Fail' ? 'bg-rose-50 text-rose-700 border-rose-100' : 
          batch.result === 'Running' ? 'bg-blue-50 text-blue-700 border-blue-100' : 
          'bg-amber-50 text-amber-700 border-amber-100'
        }`}>
          {batch.result}
        </span>
      </td>
    </tr>
    <tr className="h-6 bg-white border-b border-slate-100">
      <td colSpan={5} className="border-l-[8px] border-indigo-600"></td>
    </tr>
  </React.Fragment>
);

/**
 * MAIN APP COMPONENT
 */
const App = () => {
  const [expandedPOs, setExpandedPOs] = useState(new Set(['PO-2024-001']));
  const [expandedBatches, setExpandedBatches] = useState(new Set());
  const [searchTerm, setSearchTerm] = useState('');
  
  const [showFilters, setShowFilters] = useState(false);
  const [statusFilter, setStatusFilter] = useState('All');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [paramFilters, setParamFilters] = useState([{ key: 'abc', value: '' }]);

  const groupedData = useMemo(() => {
    const map = {};
    MOCK_QUERY_DATA.forEach(row => {
      const matchesSearch = row.po.toLowerCase().includes(searchTerm.toLowerCase()) || 
                            row.batch.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesStatus = statusFilter === 'All' || row.result === statusFilter;
      const matchesParams = paramFilters.every(f => !f.value || String(row[f.key] || '').toLowerCase().includes(f.value.toLowerCase()));
      const rowDate = row.timestamp.split(' ')[0];
      const matchesDate = (!startDate || rowDate >= startDate) && (!endDate || rowDate <= endDate);

      if (matchesSearch && matchesStatus && matchesParams && matchesDate) {
        if (!map[row.po]) map[row.po] = [];
        map[row.po].push(row);
      }
    });
    return map;
  }, [searchTerm, statusFilter, paramFilters, startDate, endDate]);

  const handleParamChange = (index, field, value) => {
    const newParams = [...paramFilters];
    newParams[index][field] = value;
    setParamFilters(newParams);
  };

  const addParamFilter = () => setParamFilters([...paramFilters, { key: 'abc', value: '' }]);
  const removeParamFilter = (index) => setParamFilters(paramFilters.filter((_, i) => i !== index));
  const resetFilters = () => {
    setStatusFilter('All');
    setParamFilters([{ key: 'abc', value: '' }]);
    setStartDate(''); setEndDate(''); setSearchTerm('');
  };

  const togglePO = (poId) => {
    const next = new Set(expandedPOs);
    next.has(poId) ? next.delete(poId) : next.add(poId);
    setExpandedPOs(next);
  };

  const toggleBatch = (batchId) => {
    const next = new Set(expandedBatches);
    next.has(batchId) ? next.delete(batchId) : next.add(batchId);
    setExpandedBatches(next);
  };

  return (
    <div className="min-h-screen bg-[#f1f5f9] p-4 md:p-10 font-sans text-slate-900">
      <div className="max-w-6xl mx-auto">
        <Header />

        <div className="relative z-40 mb-6 flex flex-col md:flex-row gap-3">
          <div className="relative flex-1 group">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500" size={20} />
            <input 
              type="text" 
              placeholder="Search PO number..."
              className="w-full pl-12 pr-4 py-3.5 bg-white border border-slate-200 rounded-2xl outline-none text-sm font-medium shadow-sm transition-all focus:ring-4 focus:ring-indigo-500/10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <div className="relative">
            <button 
              onClick={() => setShowFilters(!showFilters)}
              className={`flex items-center gap-3 px-6 py-3.5 rounded-2xl text-sm font-black border transition-all ${
                showFilters ? 'bg-indigo-600 text-white border-indigo-600 shadow-lg' : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300'
              }`}
            >
              <Settings2 size={18} />
              Advanced Filter
              <ChevronDown size={16} className={showFilters ? 'rotate-180' : ''} />
            </button>

            <FilterPanel 
              showFilters={showFilters} setShowFilters={setShowFilters}
              statusFilter={statusFilter} setStatusFilter={setStatusFilter}
              startDate={startDate} setStartDate={setStartDate}
              endDate={endDate} setEndDate={setEndDate}
              paramFilters={paramFilters} handleParamChange={handleParamChange}
              addParamFilter={addParamFilter} removeParamFilter={removeParamFilter}
              resetFilters={resetFilters}
            />
          </div>
        </div>

        <div className="bg-white rounded-[2.5rem] shadow-sm border border-slate-200 overflow-hidden">
          <table className="w-full border-collapse">
            <thead>
              <tr className="bg-slate-50/50 border-b border-slate-100">
                <th className="px-8 py-6 text-left font-black text-[10px] text-slate-400 uppercase tracking-[0.25em] w-1/3">Batch Hierarchy</th>
                {['a', 'b', 'c', 'Result'].map(h => (
                  <th key={h} className="px-8 py-6 text-center font-black text-[10px] text-slate-400 uppercase tracking-[0.25em] w-[12%] border-l border-slate-100/50">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
               {Object.entries(groupedData).map(([poId, batches]) => (
                <React.Fragment key={poId}>
                  <tr className="hover:bg-slate-50/80 cursor-pointer group transition-all" onClick={() => togglePO(poId)}>
                    <td className="px-8 py-7 flex items-center gap-5">
                      <div className={`w-10 h-10 rounded-2xl flex items-center justify-center transition-all ${expandedPOs.has(poId) ? 'bg-indigo-600 text-white shadow-lg rotate-90' : 'bg-slate-100 text-slate-400 group-hover:text-indigo-600'}`}>
                        <ChevronRight size={20} />
                      </div>
                      <div className="flex flex-col">
                        <span className="text-xl font-black text-slate-800 tracking-tight">{poId}</span>
                        <span className="text-[10px] font-black text-indigo-500/60 uppercase tracking-widest mt-1">{batches.length} BATCHES</span>
                      </div>
                    </td>
                    <td colSpan={4}></td>
                  </tr>
                  {expandedPOs.has(poId) && batches.map((batch) => {
                    const batchKey = `${poId}-${batch.batch}`;
                    const isExpanded = expandedBatches.has(batchKey);
                    return (
                      <React.Fragment key={batchKey}>
                        <tr 
                          className={`cursor-pointer transition-all border-l-[8px] ${isExpanded ? 'border-indigo-600 bg-indigo-50/20' : 'border-transparent bg-white hover:bg-slate-50/50'}`}
                          onClick={() => toggleBatch(batchKey)}
                        >
                          <td className="px-8 py-5 pl-20 flex items-center gap-4">
                            <div className={`w-7 h-7 rounded-xl flex items-center justify-center border-2 ${isExpanded ? 'bg-indigo-600 border-indigo-600 text-white shadow-sm' : 'bg-white border-slate-100 text-slate-300'}`}>
                              <ChevronDown size={14} className={isExpanded ? '' : '-rotate-90'} />
                            </div>
                            <div className="flex flex-col">
                              <span className="font-bold text-slate-700 text-base">{batch.batch}</span>
                              <div className="flex gap-3 text-[9px] font-black uppercase text-slate-400 mt-1">
                                <span className="flex items-center gap-1"><Box size={10} /> {batch.abc}</span>
                                <span className="flex items-center gap-1"><Activity size={10} /> {batch.def}</span>
                              </div>
                            </div>
                          </td>
                          <td colSpan={4}></td>
                        </tr>
                        {isExpanded && <BatchDetailRow batch={batch} />}
                      </React.Fragment>
                    );
                  })}
                </React.Fragment>
              ))}
            </tbody>
          </table>
          {Object.keys(groupedData).length === 0 && (
            <div className="py-32 flex flex-col items-center justify-center">
              <Search size={48} className="text-slate-200 mb-6" />
              <h3 className="text-xl font-black text-slate-800 tracking-tight">No Matching Data</h3>
              <button onClick={resetFilters} className="mt-8 px-8 py-3 bg-indigo-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl">
                Clear Filters
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default App;
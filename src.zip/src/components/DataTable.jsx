import React, { useRef, useEffect, useState } from 'react';
import { FileText, X, Camera, Image as ImageIcon, FolderOpen, Info } from 'lucide-react';

// Badge component for file types
function TypeBadge({ type }) {
  const isImage = type?.startsWith('image/');
  const isPdf = type === 'application/pdf' || type?.endsWith('/pdf');
  const isExcel = /sheet|excel|spreadsheetml/.test(type) || /\.xlsx$|\.xls$|\.csv$/i.test(type || '');
  const base = 'text-[10px] px-2 py-1 rounded border font-black uppercase';
  if (isImage) return <span className={base + ' bg-indigo-50 text-indigo-700 border-indigo-100'}>Image</span>;
  if (isPdf)   return <span className={base + ' bg-rose-50 text-rose-700 border-rose-100'}>PDF</span>;
  if (isExcel) return <span className={base + ' bg-emerald-50 text-emerald-700 border-emerald-100'}>Excel</span>;
  return <span className={base + ' bg-slate-100 text-slate-700 border-slate-200'}>File</span>;
}

// Compress image to ~1280px width using Canvas
async function compressImage(file, maxWidth = 1280, quality = 0.85) {
  return new Promise((resolve, reject) => {
    try {
      const img = new Image();
      const reader = new FileReader();
      reader.onload = (e) => {
        img.onload = () => {
          const canvas = document.createElement('canvas');
          const ctx = canvas.getContext('2d');

          const ratio = img.width > maxWidth ? maxWidth / img.width : 1;
          canvas.width = Math.round(img.width * ratio);
          canvas.height = Math.round(img.height * ratio);
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

          canvas.toBlob((blob) => {
            if (!blob) return reject(new Error('Compression failed'));
            const compressed = new File([blob], file.name.replace(/(\.[^.]+)?$/, '-compressed.jpg'), { type: 'image/jpeg' });
            resolve({ file: compressed, previewUrl: URL.createObjectURL(blob) });
          }, 'image/jpeg', quality);
        };
        img.onerror = reject;
        img.src = e.target.result;
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    } catch (err) {
      reject(err);
    }
  });
}

export default function EditModal({ isOpen, formData, onClose, onChange, onSave, calculateDueDate,  onEdit }) {
  const cameraInputRef = useRef(null);
  const galleryInputRef = useRef(null);
  const filesInputRef = useRef(null);
  const [showPermHelp, setShowPermHelp] = useState(false);

  useEffect(() => {
    return () => {
      (formData?.evidences || []).forEach(ev => { if (ev.previewUrl) URL.revokeObjectURL(ev.previewUrl); });
    };
  }, [formData?.evidences]);

  const sizeLabel = (size) => size > 1024 * 1024
    ? (size / (1024 * 1024)).toFixed(1) + ' MB'
    : (size / 1024).toFixed(1) + ' KB';

  async function handleFilesPicked(fileList) {
    if (!fileList || fileList.length === 0) return;
    const incoming = Array.from(fileList);
    const processed = [];

    for (const f of incoming) {
      try {
        if (f.type?.startsWith('image/')) {
          const { file: compressed, previewUrl } = await compressImage(f);
          processed.push({
            name: compressed.name,
            size: sizeLabel(compressed.size),
            type: compressed.type,
            lastModified: compressed.lastModified,
            previewUrl,
            file: compressed,
          });
        } else {
          processed.push({
            name: f.name,
            size: sizeLabel(f.size),
            type: f.type || 'application/octet-stream',
            lastModified: f.lastModified,
            previewUrl: null,
            file: f,
          });
        }
      } catch {
        processed.push({
          name: f.name,
          size: sizeLabel(f.size),
          type: f.type || 'application/octet-stream',
          lastModified: f.lastModified,
          previewUrl: null,
          file: f,
        });
      }
    }

    const newList = [ ...(formData.evidences || []), ...processed ];
    onChange({ ...formData, evidences: newList });
  }

  const onCameraChange = async (e) => { await handleFilesPicked(e.target.files); e.target.value = null; };
  const onGalleryChange = async (e) => { await handleFilesPicked(e.target.files); e.target.value = null; };
  const onFilesChange   = async (e) => { await handleFilesPicked(e.target.files); e.target.value = null; };

  const removeFile = (index) => {
    const list = [...(formData.evidences || [])];
    const ev = list[index];
    if (ev?.previewUrl) URL.revokeObjectURL(ev.previewUrl);
    list.splice(index, 1);
    onChange({ ...formData, evidences: list });
  };

  if (!isOpen) return null;

  const formatForInput = (date) => {
    if (!date) return "";
    if (typeof date === "string") return date.split("T")[0];
    return new Date(date).toISOString().split("T")[0];
  };

  const handleFrequencyChange = (e) => {
    const newFreq = e.target.value;
    const nextDue = calculateDueDate?.(formData.start_Date, newFreq);
    onChange({ ...formData, m_Frequency: newFreq, due_Date: nextDue });
  };

  const handleStartDateChange = (e) => {
    const newStart = e.target.value;
    const nextDue = calculateDueDate?.(newStart, formData.m_Frequency);
    onChange({ ...formData, start_Date: newStart, due_Date: nextDue });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4">
      <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={onClose}></div>

      <div className="relative bg-white rounded-2xl sm:rounded-3xl shadow-2xl w-full max-w-2xl max-h-[95vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-6 bg-slate-50 border-b border-slate-200 flex justify-between items-center">
          <div>
            <h3 className="text-lg sm:text-xl font-black text-slate-800 uppercase tracking-tight">
              {formData?.id ? 'Edit Requirement' : 'Add Requirement'}
            </h3>
            <p className="text-[10px] text-slate-400 font-bold">NEXT REVIEW CALCULATED AUTOMATICALLY</p>
          </div>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center bg-white border rounded-full text-slate-400 hover:text-slate-600">&times;</button>
        </div>

        {/* Form */}
        <form onSubmit={onSave} className="overflow-y-auto p-4 sm:p-6 space-y-5">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-5">
            {/* Act / Rule */}
            <div className="md:col-span-2">
              <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Act / Rule</label>
              <input type="text" required className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" value={formData.act} onChange={(e) => onChange({ ...formData, act: e.target.value })} />
            </div>

            {/* Compliance Requirement */}
            <div className="md:col-span-2">
              <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Compliance Requirement</label>
              <textarea required rows="3" className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" value={formData.c_Requirement} onChange={(e) => onChange({ ...formData, c_Requirement: e.target.value })} />
            </div>

            {/* Evidence / Record Selection */}
            <div className="md:col-span-2 bg-indigo-50/50 p-4 rounded-2xl border border-indigo-100">
              <div className="flex items-start justify-between">
                <label className="block text-[10px] font-black text-indigo-600 uppercase tracking-widest mb-2">Evidence / Record Selection</label>
                <button type="button" onClick={() => setShowPermHelp(v => !v)} className="text-indigo-600 text-xs font-bold inline-flex items-center gap-1">
                  <Info className="w-3.5 h-3.5" /> Permissions / Camera Tips
                </button>
              </div>

              {/* Hidden Inputs */}
              <input type="file" ref={cameraInputRef} className="hidden" accept="image/*;capture=camera" onChange={onCameraChange} />
              <input type="file" ref={galleryInputRef} className="hidden" accept="image/*" multiple onChange={onGalleryChange} />
              <input type="file" ref={filesInputRef} className="hidden" accept=".pdf,.doc,.docx,.xls,.xlsx,.csv,image/*" multiple onChange={onFilesChange} />

              {showPermHelp && (
                <div className="mt-2 mb-3 p-3 bg-white border border-indigo-100 rounded-xl text-[12px] text-slate-600">
                  <p className="mb-1 font-bold text-indigo-700">If camera doesn’t open:</p>
                  <ul className="list-disc pl-5 space-y-1">
                    <li>Ensure site is served over <span className="font-bold">HTTPS</span> when using live camera APIs (getUserMedia).</li>
                    <li><span className="font-bold">Android Chrome</span>: If camera option is missing, this button uses a camera hint. You can also pick from Photos.</li>
                    <li><span className="font-bold">iOS Safari</span>: Allow camera/photos permission when prompted; manage under Settings → Safari → Camera.</li>
                  </ul>
                </div>
              )}

              {(formData.evidences?.length || 0) === 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <button type="button" onClick={() => cameraInputRef.current?.click()} className="w-full py-3 border-2 border-dashed border-indigo-200 rounded-xl flex items-center justify-center gap-2 hover:bg-indigo-50 hover:border-indigo-400 transition-all">
                    <Camera className="w-5 h-5 text-indigo-600" />
                    <span className="text-sm font-bold text-indigo-700">Take Photo</span>
                  </button>

                  <button type="button" onClick={() => galleryInputRef.current?.click()} className="w-full py-3 border-2 border-dashed border-indigo-200 rounded-xl flex items-center justify-center gap-2 hover:bg-indigo-50 hover:border-indigo-400 transition-all">
                    <ImageIcon className="w-5 h-5 text-indigo-600" />
                    <span className="text-sm font-bold text-indigo-700">Pick from Photos</span>
                  </button>

                  <button type="button" onClick={() => filesInputRef.current?.click()} className="w-full py-3 border-2 border-dashed border-indigo-200 rounded-xl flex items-center justify-center gap-2 hover:bg-indigo-50 hover:border-indigo-400 transition-all">
                    <FolderOpen className="w-5 h-5 text-indigo-600" />
                    <span className="text-sm font-bold text-indigo-700">Browse Files</span>
                  </button>
                </div>
              ) : (
                <div className="space-y-2">
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <button type="button" onClick={() => cameraInputRef.current?.click()} className="w-full py-2 border-2 border-dashed border-indigo-200 rounded-xl text-xs font-bold text-indigo-700 hover:bg-indigo-50">Add Photo</button>
                    <button type="button" onClick={() => galleryInputRef.current?.click()} className="w-full py-2 border-2 border-dashed border-indigo-200 rounded-xl text-xs font-bold text-indigo-700 hover:bg-indigo-50">Add from Photos</button>
                    <button type="button" onClick={() => filesInputRef.current?.click()} className="w-full py-2 border-2 border-dashed border-indigo-200 rounded-xl text-xs font-bold text-indigo-700 hover:bg-indigo-50">Add Files</button>
                  </div>

                  <div className="divide-y divide-slate-100 bg-white border border-indigo-100 rounded-xl">
                    {(formData.evidences || []).map((ev, idx) => (
  <div key={idx} className="flex items-center justify-between p-3">
    <div className="flex items-center gap-3 min-w-0">
      {/* File icon */}
      <div className="w-10 h-10 bg-indigo-50 rounded-lg flex items-center justify-center text-indigo-600">
        <FileText className="w-5 h-5" />
      </div>

      {/* File name and type */}
      <div className="flex flex-col min-w-0">
        <a
          href={`http://localhost:3000${ev.filePath}`} // Open uploaded file
          target="_blank"
          rel="noopener noreferrer"
          className="text-sm font-bold text-slate-800 truncate max-w-[220px] hover:underline"
        >
          {ev.filename || ev.name}
        </a>
        <div className="flex items-center gap-2">
          <TypeBadge type={ev.fileType || ev.type} />
          {ev.size && <span className="text-[10px] text-slate-400 uppercase font-black">{ev.size}</span>}
        </div>
      </div>
    </div>

    {/* Remove button */}
    <button
      type="button"
      onClick={() => removeFile(idx)}
      className="h-10 px-3 text-rose-600 hover:bg-rose-50 rounded-lg text-xs font-bold"
    >
      <X className="w-4 h-4" />
    </button>
  </div>
))}

                  </div>
                </div>
              )}
            </div>

            {/* Compliance Status */}
            <div>
              <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Compliance Status</label>
              <select className="w-full h-11 p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none" value={formData.c_status} onChange={(e) => onChange({ ...formData, c_status: e.target.value })}>
                <option value="Compliant">Compliant</option>
                <option value="Non-Compliant">Non-Compliant</option>
                <option value="Pending">Pending</option>
                <option value="Overdue">Overdue</option>
              </select>
            </div>

            {/* Due Date */}
            <div>
              <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Start Date</label>
              <input type="date" required className="w-full h-11 p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none" value={formatForInput(formData.start_Date)} onChange={handleStartDateChange} />
            </div>

            {/* Frequency */}
            <div>
              <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Monitoring Frequency</label>
              <select className="w-full h-11 p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none" value={formData.m_Frequency} onChange={handleFrequencyChange}>
                <option value="Daily">Daily</option>
                <option value="Monthly">Monthly</option>
                <option value="Quarterly">Quarterly</option>
                <option value="Bi-Annual">Bi-Annual</option>
                <option value="Annual">Annual</option>
              </select>
            </div>

            {/* Next Review (Auto) */}
            <div>
              <label className="block text-[10px] font-black text-indigo-600 uppercase tracking-widest mb-1">Next Review Date (Auto)</label>
              <input type="date" readOnly className="w-full h-11 p-3 bg-indigo-50 border border-indigo-100 text-indigo-700 font-bold rounded-xl outline-none cursor-not-allowed" value={formatForInput(formData.due_Date)} />
            </div>

            {/* Action Plan */}
            <div className="md:col-span-2">
              <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Action Plan</label>
              <textarea rows="3" className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none" value={formData.action_Plan} onChange={(e) => onChange({ ...formData, action_Plan: e.target.value })} />
            </div>
          </div>

          <div>
              <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Type</label>
              <select className="w-full h-11 p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none" value={formData.type} onChange={(e) => onChange({ ...formData, type: e.target.value })}>
                <option value="Daily">A</option>
                <option value="Monthly">B</option>
                <option value="Quarterly">C</option>
                <option value="Bi-Annual">D</option>
                
              </select>
            </div>

          {/* Footer */}
          <div className="pt-4 sm:pt-6 flex flex-col sm:flex-row justify-end gap-3">
            <button type="button" onClick={onClose} className="h-10 px-4 text-slate-500 bg-slate-100 hover:bg-slate-200 rounded-xl font-bold text-[12px]">Discard</button>
            <button type="submit" className="h-10 px-6 bg-indigo-600 text-white rounded-xl font-bold text-[12px] shadow-lg hover:shadow-indigo-200">{formData?.id ? 'Update Record' : 'Add Record'}</button>
          </div>
        </form>
      </div>
    </div>
  );
}

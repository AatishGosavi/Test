import React from 'react';
import { Layers } from 'lucide-react';

const Header = () => (
  <div className="flex items-center justify-between mb-8">
    <div className="flex items-center gap-4">
      <div className="p-3 bg-indigo-600 rounded-2xl shadow-xl shadow-indigo-200">
        <Layers className="text-white w-6 h-6" />
      </div>
      <div>
        <h1 className="text-2xl font-black text-slate-800 tracking-tight">Production Intel</h1>
        <p className="text-slate-500 text-[10px] font-bold uppercase tracking-[0.2em]">Operational Matrix v2.4</p>
      </div>
    </div>
    <div className="hidden md:flex gap-2">
      <div className="px-4 py-2 bg-white rounded-xl border border-slate-200 shadow-sm flex items-center gap-2">
        <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
        <span className="text-[10px] font-black text-slate-500 uppercase">System Online</span>
      </div>
    </div>
  </div>
);

export default Header;
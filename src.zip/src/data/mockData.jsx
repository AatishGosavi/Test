export const MOCK_QUERY_DATA = [
  { po: 'PO-2024-001', batch: 'batch1', p1: 'Pass', p10: 'Pass', p11: 'Fail', result: 'Partial', timestamp: '2024-05-20 10:30', abc: 'Val1', def: 'X' },
  { po: 'PO-2024-001', batch: 'batch2', p1: 'Pass', p10: 'Pass', p11: 'Pass', result: 'Pass', timestamp: '2024-05-20 11:15', abc: 'Val2', def: 'Y' },
  { po: 'PO-2024-002', batch: 'batch3', p1: 'Fail', p10: 'N/A', p11: 'N/A', result: 'Fail', timestamp: '2024-05-21 09:00', abc: 'Val1', def: 'Z' },
  { po: 'PO-2024-003', batch: 'batch4', p1: 'Pass', p10: 'Pending', p11: 'N/A', result: 'Running', timestamp: '2024-05-22 12:45', abc: 'Val3', def: 'X' },
];
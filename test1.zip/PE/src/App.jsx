import React, { useState, useMemo } from 'react';
import { Search, Settings2, ChevronDown } from 'lucide-react';
import Header from './components/layout/Header';
import DataTable from './components/table/DataTable';
import FilterPanel from './components/FilterPanel';
import { MOCK_QUERY_DATA } from './constants/mockData';

const App = () => {
  const [expandedPOs, setExpandedPOs] = useState(new Set(['PO-2024-001']));
  const [expandedBatches, setExpandedBatches] = useState(new Set());
  const [searchTerm, setSearchTerm] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  
  // Filter States
  const [statusFilter, setStatusFilter] = useState('All');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [paramFilters, setParamFilters] = useState([{ key: 'abc', value: '' }]);

  // --- NEW: Calculate Active Filter Count ---
  const activeFilterCount = useMemo(() => {
    let count = 0;
    if (statusFilter !== 'All') count++;
    if (startDate) count++;
    if (endDate) count++;
    // Count parameter rows that actually have a search value typed in
    const activeParams = paramFilters.filter(f => f.value.trim() !== '').length;
    return count + activeParams;
  }, [statusFilter, startDate, endDate, paramFilters]);

  const groupedData = useMemo(() => {
    const map = {};
    MOCK_QUERY_DATA.forEach(row => {
      const matchesSearch = row.po.toLowerCase().includes(searchTerm.toLowerCase()) || 
                            row.batch.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesStatus = statusFilter === 'All' || row.result === statusFilter;
      const rowDate = row.timestamp.split(' ')[0];
      const matchesDate = (!startDate || rowDate >= startDate) && (!endDate || rowDate <= endDate);

      if (matchesSearch && matchesStatus && matchesDate) {
        if (!map[row.po]) map[row.po] = [];
        map[row.po].push(row);
      }
    });
    return map;
  }, [searchTerm, statusFilter, startDate, endDate]);

  const togglePO = (id) => {
    const n = new Set(expandedPOs); n.has(id) ? n.delete(id) : n.add(id); setExpandedPOs(n);
  };
  const toggleBatch = (id) => {
    const n = new Set(expandedBatches); n.has(id) ? n.delete(id) : n.add(id); setExpandedBatches(n);
  };

  return (
    <div className="min-h-screen bg-[#f8fafc] p-10 text-slate-900">
      <div className="max-w-6xl mx-auto">
        <Header />
        
        <div className="relative mb-6 flex gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
            <input 
              className="w-full pl-12 pr-4 py-4 bg-white border border-slate-200 rounded-2xl outline-none focus:ring-2 ring-indigo-500/10 transition-all" 
              placeholder="Search PO number or Batch ID..." 
              value={searchTerm} 
              onChange={e => setSearchTerm(e.target.value)} 
            />
          </div>
          
          <div className="relative">
            <button 
              onClick={() => setShowFilters(!showFilters)} 
              className={`flex items-center gap-3 px-6 py-4 rounded-2xl text-sm font-black border transition-all relative ${
                showFilters || activeFilterCount > 0 
                ? 'bg-indigo-600 text-white border-indigo-600 shadow-lg shadow-indigo-100' 
                : 'bg-white border-slate-200 text-slate-600'
              }`}
            >
              <Settings2 size={18} />
              <span>Advanced Filter</span>
              
              {/* --- NEW: Active Filter Badge --- */}
              {activeFilterCount > 0 && (
                <span className="flex items-center justify-center bg-white text-indigo-600 w-5 h-5 rounded-full text-[10px] font-black ml-1">
                  {activeFilterCount}
                </span>
              )}
              
              <ChevronDown size={16} className={`transition-transform ${showFilters ? 'rotate-180' : ''}`} />
            </button>

            {showFilters && (
              <FilterPanel 
                setShowFilters={setShowFilters} 
                statusFilter={statusFilter} 
                setStatusFilter={setStatusFilter}
                startDate={startDate} 
                setStartDate={setStartDate} 
                endDate={endDate} 
                setEndDate={setEndDate}
                paramFilters={paramFilters} 
                setParamFilters={setParamFilters}
                resetFilters={() => { 
                  setStatusFilter('All'); 
                  setStartDate(''); 
                  setEndDate(''); 
                  setParamFilters([{ key: 'abc', value: '' }]);
                }}
              />
            )}
          </div>
        </div>

        <DataTable 
          groupedData={groupedData} 
          expandedPOs={expandedPOs} 
          togglePO={togglePO}
          expandedBatches={expandedBatches} 
          toggleBatch={toggleBatch}
          resetFilters={() => setSearchTerm('')}
        />
      </div>
    </div>
  );
};

export default App;
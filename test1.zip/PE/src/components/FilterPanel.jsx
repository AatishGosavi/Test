import React from 'react';
import { X, Plus, Trash2, RefreshCcw, Calendar } from 'lucide-react';

const FilterPanel = ({ 
  setShowFilters, 
  paramFilters, 
  handleParamChange, 
  addParamFilter, 
  removeParamFilter, 
  startDate, 
  setStartDate, 
  endDate, 
  setEndDate, 
  statusFilter, 
  setStatusFilter, 
  resetFilters 
}) => {
  return (
    <div className="absolute right-0 mt-4 w-[420px] bg-white border border-slate-200 rounded-[2rem] shadow-[0_20px_50px_rgba(0,0,0,0.15)] p-8 animate-in fade-in zoom-in-95 slide-in-from-top-4 duration-200">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h4 className="font-black text-slate-800 text-lg tracking-tight">Filter Engine</h4>
          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Refine production view</p>
        </div>
        <button onClick={() => setShowFilters(false)} className="p-2 hover:bg-slate-100 rounded-full transition-colors text-slate-400">
          <X size={20} />
        </button>
      </div>

      <div className="space-y-8">
        {/* METADATA PARAMS */}
        <div className="space-y-4">
          <div className="flex justify-between items-center px-1">
            <label className="text-[10px] font-black uppercase text-slate-400 tracking-[0.15em]">Specific Parameters</label>
            <button onClick={addParamFilter} className="text-[10px] flex items-center gap-1 font-black text-indigo-600 hover:text-indigo-700 uppercase tracking-widest">
              <Plus size={14} strokeWidth={3} /> Add Logic
            </button>
          </div>
          <div className="space-y-3 max-h-[180px] overflow-y-auto pr-2 custom-scrollbar">
            {paramFilters.map((filter, idx) => (
              <div key={idx} className="flex gap-2 items-center">
                <div className="flex-1 flex bg-slate-50 rounded-xl border border-slate-200 p-1.5 focus-within:border-indigo-300 transition-all">
                  <select 
                    className="bg-transparent text-[11px] font-black text-indigo-600 uppercase tracking-tighter outline-none px-2 cursor-pointer border-r border-slate-200"
                    value={filter.key}
                    onChange={(e) => handleParamChange(idx, 'key', e.target.value)}
                  >
                    <option value="abc">ABC</option>
                    <option value="def">DEF</option>
                  </select>
                  <input 
                    type="text"
                    placeholder="Enter value..."
                    className="flex-1 bg-transparent px-3 py-1.5 text-xs font-bold text-slate-700 outline-none"
                    value={filter.value}
                    onChange={(e) => handleParamChange(idx, 'value', e.target.value)}
                  />
                </div>
                {paramFilters.length > 1 && (
                  <button onClick={() => removeParamFilter(idx)} className="p-2.5 text-slate-300 hover:text-rose-500 rounded-xl transition-all">
                    <Trash2 size={16} />
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* DATES */}
        <div className="space-y-3">
          <label className="block px-1 text-[10px] font-black uppercase text-slate-400 tracking-[0.15em]">Capture Window</label>
          <div className="grid grid-cols-2 gap-4">
            <div className="relative">
              <Calendar size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input type="date" className="w-full text-xs font-bold p-3 pl-10 bg-slate-50 border border-slate-200 rounded-xl" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
            </div>
            <div className="relative">
              <Calendar size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input type="date" className="w-full text-xs font-bold p-3 pl-10 bg-slate-50 border border-slate-200 rounded-xl" value={endDate} onChange={(e) => setEndDate(e.target.value)} />
            </div>
          </div>
        </div>

        {/* STATUS */}
        <div className="space-y-3">
          <label className="block px-1 text-[10px] font-black uppercase text-slate-400 tracking-[0.15em]">Batch Result</label>
          <div className="flex flex-wrap gap-2 p-1.5 bg-slate-50 rounded-2xl border border-slate-200">
            {['All', 'Pass', 'Fail', 'Running'].map(status => (
              <button
                key={status}
                onClick={() => setStatusFilter(status)}
                className={`flex-1 px-3 py-2 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all ${statusFilter === status ? 'bg-white text-indigo-600 shadow-sm ring-1 ring-slate-200' : 'text-slate-400 hover:text-slate-600'}`}
              >
                {status}
              </button>
            ))}
          </div>
        </div>

        {/* ACTION FOOTER */}
        <div className="pt-4 flex gap-4">
          <button onClick={resetFilters} className="flex items-center justify-center gap-2 px-6 py-3 text-[11px] font-black text-slate-400 hover:text-slate-800 uppercase tracking-widest">
            <RefreshCcw size={16} strokeWidth={3} /> Reset
          </button>
          <button onClick={() => setShowFilters(false)} className="flex-1 px-6 py-4 text-[11px] font-black text-white uppercase tracking-[0.2em] bg-indigo-600 rounded-2xl hover:bg-indigo-700 shadow-xl shadow-indigo-100 transition-all active:scale-[0.98]">
            Update View
          </button>
        </div>
      </div>
    </div>
  );
};

export default FilterPanel;
import React from 'react';
import { X, Plus, Trash2, RefreshCcw } from 'lucide-react';

const FilterPanel = ({ 
  showFilters, 
  setShowFilters, 
  statusFilter, 
  setStatusFilter, 
  startDate, 
  setStartDate, 
  endDate, 
  setEndDate, 
  paramFilters, 
  handleParamChange, 
  addParamFilter, 
  removeParamFilter, 
  resetFilters 
}) => {
  if (!showFilters) return null;

  return (
    <div className="absolute right-0 mt-4 w-[420px] bg-white border border-slate-200 rounded-[2rem] shadow-[0_20px_50px_rgba(0,0,0,0.15)] p-8 z-50 animate-in fade-in zoom-in-95 slide-in-from-top-4 duration-200">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h4 className="font-black text-slate-800 text-lg tracking-tight">Filter Engine</h4>
          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Refine production view</p>
        </div>
        <button onClick={() => setShowFilters(false)} className="p-2 hover:bg-slate-100 rounded-full transition-colors text-slate-400">
          <X size={20} />
        </button>
      </div>
      
      <div className="space-y-8">
        {/* Dynamic Params */}
        <div className="space-y-4">
          <div className="flex justify-between items-center px-1">
            <label className="text-[10px] font-black uppercase text-slate-400 tracking-[0.15em]">Specific Parameters</label>
            <button onClick={addParamFilter} className="text-[10px] flex items-center gap-1 font-black text-indigo-600 uppercase tracking-widest">
              <Plus size={14} strokeWidth={3} /> Add Logic
            </button>
          </div>
          <div className="space-y-3 max-h-[180px] overflow-y-auto pr-2">
            {paramFilters.map((filter, idx) => (
              <div key={idx} className="flex gap-2 items-center">
                <div className="flex-1 flex bg-slate-50 rounded-xl border border-slate-200 p-1.5 focus-within:border-indigo-300 transition-all">
                  <select 
                    className="bg-transparent text-[11px] font-black text-indigo-600 uppercase outline-none px-2 border-r border-slate-200"
                    value={filter.key}
                    onChange={(e) => handleParamChange(idx, 'key', e.target.value)}
                  >
                    <option value="abc">ABC</option>
                    <option value="def">DEF</option>
                  </select>
                  <input 
                    type="text"
                    placeholder="Value..."
                    className="flex-1 bg-transparent px-3 py-1.5 text-xs font-bold text-slate-700 outline-none"
                    value={filter.value}
                    onChange={(e) => handleParamChange(idx, 'value', e.target.value)}
                  />
                </div>
                {paramFilters.length > 1 && (
                  <button onClick={() => removeParamFilter(idx)} className="p-2.5 text-slate-300 hover:text-rose-500 transition-all">
                    <Trash2 size={16} />
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="pt-4 flex gap-4">
          <button onClick={resetFilters} className="flex items-center gap-2 px-6 py-3 text-[11px] font-black text-slate-400 uppercase tracking-widest">
            <RefreshCcw size={16} /> Reset
          </button>
          <button onClick={() => setShowFilters(false)} className="flex-1 px-6 py-4 text-[11px] font-black text-white uppercase tracking-[0.2em] bg-indigo-600 rounded-2xl shadow-lg">
            Update View
          </button>
        </div>
      </div>
    </div>
  );
};

export default FilterPanel;
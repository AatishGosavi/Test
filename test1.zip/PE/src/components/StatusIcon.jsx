import React from 'react';
import { CheckCircle2, XCircle, AlertCircle } from 'lucide-react';

const StatusIcon = ({ status }) => {
  switch (status) {
    case 'Pass': return <CheckCircle2 size={14} className="text-emerald-500" />;
    case 'Fail': return <XCircle size={14} className="text-rose-500" />;
    case 'Running': return <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" />;
    default: return <AlertCircle size={14} className="text-amber-500" />;
  }
};

export default StatusIcon;
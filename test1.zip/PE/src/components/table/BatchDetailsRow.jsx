import React from 'react';
import { Calendar } from 'lucide-react';
import StatusIcon from '../StatusIcon';

const BatchDetailsRow = ({ batch }) => {
  const paramKeys = ['p1', 'p10', 'p11'];

  return (
    <React.Fragment>
      {/* NESTED HEADER ROW */}
      <tr className="bg-white">
        <td className="p-0 border-l-[8px] border-indigo-600"></td>
        {paramKeys.map((key) => (
          <td key={key} className="pt-6 pb-2 border-l border-slate-50 text-center font-black text-[10px] uppercase tracking-[0.2em] text-slate-400">
            {key}
          </td>
        ))}
        <td className="pt-6 pb-2 border-l border-slate-50 text-center font-black text-[10px] uppercase tracking-[0.2em] text-slate-400">
          Status
        </td>
      </tr>

      {/* NESTED DATA ROW */}
      <tr className="bg-white">
        <td className="px-8 py-6 pl-24 border-l-[8px] border-indigo-600 relative">
          <div className="absolute left-[5.5rem] top-0 bottom-0 w-0.5 bg-slate-50"></div>
          <div className="flex flex-col border-l-2 border-indigo-100 pl-4">
            <span className="text-[9px] font-black text-slate-300 uppercase tracking-widest mb-1 text-left">Time Captured</span>
            <div className="flex items-center gap-2 text-[11px] font-mono font-bold text-slate-500">
              <Calendar size={12} className="text-indigo-300" />
              {batch.timestamp}
            </div>
          </div>
        </td>
        
        {paramKeys.map((key) => (
          <td key={key} className="px-8 py-6 border-l border-slate-50 text-center align-middle">
            <div className="flex flex-col items-center gap-2">
              <StatusIcon status={batch[key]} />
              <span className="text-[10px] font-black text-slate-800 uppercase tracking-tighter">
                {batch[key]}
              </span>
            </div>
          </td>
        ))}

        <td className="px-8 py-6 border-l border-slate-50 text-center align-middle">
          <span className={`inline-flex items-center px-4 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-wider border shadow-sm ${
            batch.result === 'Pass' ? 'bg-emerald-50 text-emerald-700 border-emerald-100' : 
            batch.result === 'Fail' ? 'bg-rose-50 text-rose-700 border-rose-100' : 
            'bg-amber-50 text-amber-700 border-amber-100'
          }`}>
            {batch.result}
          </span>
        </td>
      </tr>

      {/* SPACER */}
      <tr className="h-4 bg-white border-b border-slate-100">
        <td colSpan={5} className="border-l-[8px] border-indigo-600"></td>
      </tr>
    </React.Fragment>
  );
};

export default BatchDetailsRow;
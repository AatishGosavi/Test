import React from 'react';
import { ChevronRight, ChevronDown, Box, Activity, Search } from 'lucide-react';
import BatchDetailsRow from './BatchDetailsRow';

const DataTable = ({ 
  groupedData, 
  expandedPOs, 
  togglePO, 
  expandedBatches, 
  toggleBatch, 
  resetFilters 
}) => {
  if (Object.keys(groupedData).length === 0) {
    return (
      <div className="py-32 flex flex-col items-center justify-center bg-white rounded-[2.5rem] border border-slate-200">
        <Search size={32} className="text-slate-200 mb-6" />
        <h3 className="text-xl font-black text-slate-800 mb-2">No Matching Data</h3>
        <button onClick={resetFilters} className="px-8 py-3 bg-indigo-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest">
          Clear Filters
        </button>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-[2.5rem] shadow-sm border border-slate-200 overflow-hidden">
      <table className="w-full border-collapse">
        <thead>
          <tr className="bg-slate-50/50 border-b border-slate-100">
            <th className="px-8 py-6 text-left font-black text-[10px] text-slate-400 uppercase tracking-[0.25em] w-1/3">Batch Hierarchy</th>
            <th className="px-8 py-6 text-center font-black text-[10px] text-slate-400 uppercase tracking-[0.25em]">A</th>
            <th className="px-8 py-6 text-center font-black text-[10px] text-slate-400 uppercase tracking-[0.25em]">B</th>
            <th className="px-8 py-6 text-center font-black text-[10px] text-slate-400 uppercase tracking-[0.25em]">C</th>
            <th className="px-8 py-6 text-center font-black text-[10px] text-slate-400 uppercase tracking-[0.25em]">Result</th>
          </tr>
        </thead>
        <tbody>
          {Object.entries(groupedData).map(([poId, batches]) => (
            <React.Fragment key={poId}>
              {/* PO ROW */}
              <tr className="hover:bg-slate-50/80 cursor-pointer transition-all border-b border-slate-50" onClick={() => togglePO(poId)}>
                <td className="px-8 py-7 flex items-center gap-5">
                  <div className={`w-10 h-10 rounded-2xl flex items-center justify-center transition-all ${expandedPOs.has(poId) ? 'bg-indigo-600 rotate-90 shadow-lg shadow-indigo-100' : 'bg-white border-2 border-slate-100'}`}>
                    <ChevronRight size={20} className={expandedPOs.has(poId) ? 'text-white' : 'text-slate-400'} />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-xl font-black text-slate-800 tracking-tight">{poId}</span>
                    <span className="text-[10px] font-black text-indigo-500 uppercase tracking-widest mt-1">{batches.length} BATCHES MATCHED</span>
                  </div>
                </td>
                <td colSpan={4}></td>
              </tr>

              {/* BATCH ROWS */}
              {expandedPOs.has(poId) && batches.map((batch) => {
                const batchKey = `${poId}-${batch.batch}`;
                const isExpanded = expandedBatches.has(batchKey);
                return (
                  <React.Fragment key={batchKey}>
                    <tr className={`cursor-pointer transition-all border-l-[8px] border-b border-slate-50 ${isExpanded ? 'border-indigo-600 bg-indigo-50/10' : 'border-transparent bg-white hover:bg-slate-50/30'}`} onClick={() => toggleBatch(batchKey)}>
                      <td className="px-8 py-5 pl-20 flex items-center gap-4">
                        <div className={`w-8 h-8 rounded-xl flex items-center justify-center border-2 ${isExpanded ? 'bg-indigo-600 border-indigo-600' : 'bg-white border-slate-100'}`}>
                          <ChevronDown size={14} className={isExpanded ? 'text-white' : 'text-slate-300'} />
                        </div>
                        <span className="font-bold text-slate-700 text-base">{batch.batch}</span>
                      </td>
                      <td colSpan={4}></td>
                    </tr>
                    {isExpanded && <BatchDetailsRow batch={batch} />}
                  </React.Fragment>
                );
              })}
            </React.Fragment>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default DataTable;